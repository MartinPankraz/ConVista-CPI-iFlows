/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {

String httpQuery = message.getHeaders()["CamelHttpQuery"];
int index = httpQuery.indexOf("=");
String className = httpQuery.substring(index + 1);//"com.sap.it.script.logging.ILogger";

StringBuilder builder = new StringBuilder();
Class clazz = Class.forName(className);
URI classFilePath = clazz.protectionDomain.codeSource.location.toURI();
File classFile = new File(classFilePath);
byte[] classFileContent = classFile.bytes;
builder << classFileContent.encodeBase64().toString();

def messageLog = messageLogFactory.getMessageLog(message);
messageLog.addAttachmentAsString("JAR file " + classFilePath.toString() + " content: Base64 encoding", builder.toString(), "text/plain");

return message;

}